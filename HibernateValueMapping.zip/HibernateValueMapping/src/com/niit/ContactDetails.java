package com.niit;

public class ContactDetails {

	String Receipient;
	String Address;
	String Phone;
	
	public String getReceipient() {
		return Receipient;
	}
	public void setReceipient(String receipient) {
		Receipient = receipient;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
}
