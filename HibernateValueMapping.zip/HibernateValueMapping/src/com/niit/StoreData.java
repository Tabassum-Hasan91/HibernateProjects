package com.niit;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StoreData {

	public static void main(String[] args) {
		
		Configuration c= new Configuration().configure();
		SessionFactory sf=c.buildSessionFactory();
		Session s=sf.openSession();
		System.out.println("Connected");
		
		Transaction t = s.beginTransaction();  
		
		ContactDetails weekdayContact=new ContactDetails();
		weekdayContact.setAddress("Malad");
		weekdayContact.setPhone("89765634677");
		weekdayContact.setReceipient("Raju");
		
		ContactDetails holidayContact=new ContactDetails();
		holidayContact.setAddress("Borivali");
		holidayContact.setPhone("89765634677");
		holidayContact.setReceipient("Farhan");
		
		Orders o1=new Orders();
		o1.setOrderId(101);
		o1.setWeekdayContact(weekdayContact);
		o1.setHolidayContact(holidayContact);
		
		s.save(o1);
		t.commit();
		System.out.println("Done");
	}
}
