package com.niit;

public class Orders {
	int orderId;
	ContactDetails weekdayContact;
	ContactDetails holidayContact;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public ContactDetails getWeekdayContact() {
		return weekdayContact;
	}
	public void setWeekdayContact(ContactDetails weekdayContact) {
		this.weekdayContact = weekdayContact;
	}
	public ContactDetails getHolidayContact() {
		return holidayContact;
	}
	public void setHolidayContact(ContactDetails holidayContact) {
		this.holidayContact = holidayContact;
	}
	
	
}
