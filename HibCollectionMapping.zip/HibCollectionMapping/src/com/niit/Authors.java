package com.niit;

import java.util.*;

public class Authors {
	int authorId;
	String authorName;
	Set<Books> bookList;
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public Set<Books> getBookList() {
		return bookList;
	}
	public void setBookList(Set<Books> bookList) {
		this.bookList = bookList;
	}

}
