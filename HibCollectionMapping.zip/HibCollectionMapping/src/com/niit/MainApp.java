package com.niit;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {
	public static void main(String[] args) {
		Configuration c=new Configuration().configure();
		
		SessionFactory sf=c.buildSessionFactory();
		Session s=sf.openSession();
		
		Transaction t=s.beginTransaction();
		Books b1=new Books();
		b1.setBookId(100);
		b1.setBookName("Harry Potter Part1");
		
		Books b2=new Books();
		b2.setBookId(101);
		b2.setBookName("Harry Potter Part2");
		
		Set<Books> mySet=new HashSet<>();
		mySet.add(b1);
		mySet.add(b2);
		
		Authors a=new Authors();
		a.setAuthorId(301);
		a.setAuthorName("JK Rowling");
		a.setBookList(mySet);
		
		s.save(a);
		t.commit();
		s.close();
		
		System.out.println("Done");
		
	}

}
